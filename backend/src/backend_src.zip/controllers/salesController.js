const { successResponse, errorResponse } = require('../utils/apiResponse');
const { quotationModel, estimateModel, salesOrderModel, paymentModel, creditNoteModel, debitNoteModel } = require('../models/salesModel');

const quotationController = {
  async getAll(req, res) {
    try {
      const companyId = req.headers['x-company-id'] || req.user?.company_id || req.query?.company_id || req.body?.company_id;
      if (!companyId) return errorResponse(res, 400, 'Company ID is required');
      const { status, page, limit } = req.query;
      const branchId = req.headers['x-branch-id'] || req.query.branch_id || req.user?.branch_id;
      const result = await quotationModel.findByCompany(companyId, { status, branch_id: branchId, page: parseInt(page) || 1, limit: parseInt(limit) || 50 });
      return successResponse(res, 200, 'Quotations fetched', result);
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async getById(req, res) {
    try {
      const quote = await quotationModel.findById(req.params.id);
      if (!quote) return errorResponse(res, 404, 'Quotation not found');
      return successResponse(res, 200, 'Quotation fetched', quote);
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async create(req, res) {
    try {
      const companyId = req.headers['x-company-id'] || req.user?.company_id || req.query?.company_id || req.body?.company_id || req.body?.companyId || 'tech';
      let num = req.body.number || req.body.quotation_number;
      if (!num) {
        try {
          const [count] = await require('../config/db').execute('SELECT COUNT(*) as cnt FROM quotations WHERE company_id = ?', [companyId]);
          num = `QT-${new Date().getFullYear()}-${String((count[0]?.cnt || 0) + 1).padStart(3, '0')}`;
        } catch {
          num = `QT-${Date.now().toString().slice(-6)}`;
        }
      }
      const quoteData = { ...req.body, company_id: companyId, quotation_number: num, number: num, created_by: req.user?.id };
      const id = await quotationModel.create(quoteData);
      return successResponse(res, 201, 'Quotation created', { id, quotation_number: num, quotation: { ...quoteData, id } });
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async update(req, res) {
    try {
      await quotationModel.update(req.params.id, req.body);
      return successResponse(res, 200, 'Quotation updated');
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async delete(req, res) {
    try {
      const userRole = String(req.user?.role || req.user?.role_name || '').toLowerCase().trim();
      if (userRole.includes('client')) {
        return errorResponse(res, 403, 'Clients are not permitted to delete quotations');
      }
      await quotationModel.delete(req.params.id);
      return successResponse(res, 200, 'Quotation deleted');
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async convertToInvoice(req, res) {
    try {
      const companyId = req.headers['x-company-id'] || req.user?.company_id || req.query?.company_id || req.body?.company_id;
      if (!companyId) return errorResponse(res, 400, 'Company ID is required');
      const invoiceId = await quotationModel.convertToInvoice(req.params.id, companyId);
      return successResponse(res, 200, 'Converted to invoice', { invoiceId });
    } catch (err) { return errorResponse(res, 500, err.message); }
  }
};

const estimateController = {
  async getAll(req, res) {
    try {
      const companyId = req.headers['x-company-id'] || req.user?.company_id || req.query?.company_id || req.body?.company_id;
      if (!companyId) return errorResponse(res, 400, 'Company ID is required');
      const { status, page, limit } = req.query;
      const branchId = req.headers['x-branch-id'] || req.query.branch_id || req.user?.branch_id;
      const result = await estimateModel.findByCompany(companyId, { status, branch_id: branchId, page: parseInt(page) || 1, limit: parseInt(limit) || 50 });
      return successResponse(res, 200, 'Estimates fetched', result);
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async getById(req, res) {
    try {
      const est = await estimateModel.findById(req.params.id);
      if (!est) return errorResponse(res, 404, 'Estimate not found');
      return successResponse(res, 200, 'Estimate fetched', est);
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async create(req, res) {
    try {
      const companyId = req.headers['x-company-id'] || req.user?.company_id || req.query?.company_id || req.body?.company_id || req.body?.companyId || 'tech';
      let num = req.body.number || req.body.estimate_number;
      if (!num) {
        try {
          const [count] = await require('../config/db').execute('SELECT COUNT(*) as cnt FROM estimates WHERE company_id = ?', [companyId]);
          num = `EST-${new Date().getFullYear()}-${String((count[0]?.cnt || 0) + 1).padStart(3, '0')}`;
        } catch {
          num = `EST-${Date.now().toString().slice(-6)}`;
        }
      }
      const estData = { ...req.body, company_id: companyId, estimate_number: num, number: num, created_by: req.user?.id };
      const id = await estimateModel.create(estData);
      return successResponse(res, 201, 'Estimate created', { id, estimate_number: num, estimate: { ...estData, id } });
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async update(req, res) {
    try {
      await estimateModel.update(req.params.id, req.body);
      return successResponse(res, 200, 'Estimate updated');
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async delete(req, res) {
    try {
      const userRole = String(req.user?.role || req.user?.role_name || '').toLowerCase().trim();
      if (userRole.includes('client')) {
        return errorResponse(res, 403, 'Clients are not permitted to delete estimates');
      }
      await estimateModel.delete(req.params.id);
      return successResponse(res, 200, 'Estimate deleted');
    } catch (err) { return errorResponse(res, 500, err.message); }
  }
};

const salesOrderController = {
  async getAll(req, res) {
    try {
      const companyId = req.headers['x-company-id'] || req.user?.company_id || req.query?.company_id || req.body?.company_id;
      if (!companyId) return errorResponse(res, 400, 'Company ID is required');
      const { status, page, limit } = req.query;
      const branchId = req.headers['x-branch-id'] || req.query.branch_id || req.user?.branch_id;
      const result = await salesOrderModel.findByCompany(companyId, { status, branch_id: branchId, page: parseInt(page) || 1, limit: parseInt(limit) || 50 });
      return successResponse(res, 200, 'Sales orders fetched', result);
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async getById(req, res) {
    try {
      const so = await salesOrderModel.findById(req.params.id);
      if (!so) return errorResponse(res, 404, 'Sales order not found');
      return successResponse(res, 200, 'Sales order fetched', so);
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async create(req, res) {
    try {
      const companyId = req.headers['x-company-id'] || req.user?.company_id || req.query?.company_id || req.body?.company_id;
      if (!companyId) return errorResponse(res, 400, 'Company ID is required');
      const [count] = await require('../config/db').execute('SELECT COUNT(*) as cnt FROM sales_orders WHERE company_id = ?', [companyId]);
      const num = `SO-${new Date().getFullYear()}-${String(count[0].cnt + 1).padStart(3, '0')}`;
      const id = await salesOrderModel.create({ ...req.body, company_id: companyId, order_number: num, created_by: req.user?.id });
      return successResponse(res, 201, 'Sales order created', { id, order_number: num });
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async update(req, res) {
    try {
      await salesOrderModel.update(req.params.id, req.body);
      return successResponse(res, 200, 'Sales order updated');
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async delete(req, res) {
    try {
      await salesOrderModel.delete(req.params.id);
      return successResponse(res, 200, 'Sales order deleted');
    } catch (err) { return errorResponse(res, 500, err.message); }
  }
};

const paymentController = {
  async getAll(req, res) {
    try {
      const companyId = req.headers['x-company-id'] || req.user?.company_id || req.query?.company_id || req.body?.company_id;
      if (!companyId) return errorResponse(res, 400, 'Company ID is required');
      const { type, page, limit } = req.query;
      const payments = await paymentModel.findByCompany(companyId, { type, page: parseInt(page) || 1, limit: parseInt(limit) || 50 });
      return successResponse(res, 200, 'Payments fetched', payments);
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async getById(req, res) {
    try {
      const payment = await paymentModel.findById(req.params.id);
      if (!payment) return errorResponse(res, 404, 'Payment not found');
      return successResponse(res, 200, 'Payment fetched', payment);
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async create(req, res) {
    try {
      const companyId = req.headers['x-company-id'] || req.user?.company_id || req.query?.company_id || req.body?.company_id;
      if (!companyId) return errorResponse(res, 400, 'Company ID is required');
      const [count] = await require('../config/db').execute('SELECT COUNT(*) as cnt FROM payments WHERE company_id = ?', [companyId]);
      const num = `PAY-${new Date().getFullYear()}-${String(count[0].cnt + 1).padStart(3, '0')}`;
      const id = await paymentModel.create({ ...req.body, company_id: companyId, payment_number: num, created_by: req.user?.id });
      return successResponse(res, 201, 'Payment created', { id, payment_number: num });
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async delete(req, res) {
    try {
      await paymentModel.delete(req.params.id);
      return successResponse(res, 200, 'Payment deleted');
    } catch (err) { return errorResponse(res, 500, err.message); }
  }
};

const creditNoteController = {
  async getAll(req, res) {
    try {
      const companyId = req.headers['x-company-id'] || req.user?.company_id || req.query?.company_id || req.body?.company_id;
      if (!companyId) return errorResponse(res, 400, 'Company ID is required');
      const notes = await creditNoteModel.findByCompany(companyId);
      return successResponse(res, 200, 'Credit notes fetched', notes);
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async create(req, res) {
    try {
      const companyId = req.headers['x-company-id'] || req.user?.company_id || req.query?.company_id || req.body?.company_id;
      if (!companyId) return errorResponse(res, 400, 'Company ID is required');
      const [count] = await require('../config/db').execute('SELECT COUNT(*) as cnt FROM credit_notes WHERE company_id = ?', [companyId]);
      const num = `CN-${new Date().getFullYear()}-${String(count[0].cnt + 1).padStart(3, '0')}`;
      const id = await creditNoteModel.create({ ...req.body, company_id: companyId, credit_note_number: num, created_by: req.user?.id });
      return successResponse(res, 201, 'Credit note created', { id, credit_note_number: num });
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async update(req, res) {
    try {
      await creditNoteModel.update(req.params.id, req.body);
      return successResponse(res, 200, 'Credit note updated');
    } catch (err) { return errorResponse(res, 500, err.message); }
  }
};

const debitNoteController = {
  async getAll(req, res) {
    try {
      const companyId = req.headers['x-company-id'] || req.user?.company_id || req.query?.company_id || req.body?.company_id;
      if (!companyId) return errorResponse(res, 400, 'Company ID is required');
      const notes = await debitNoteModel.findByCompany(companyId);
      return successResponse(res, 200, 'Debit notes fetched', notes);
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async create(req, res) {
    try {
      const companyId = req.headers['x-company-id'] || req.user?.company_id || req.query?.company_id || req.body?.company_id;
      if (!companyId) return errorResponse(res, 400, 'Company ID is required');
      const [count] = await require('../config/db').execute('SELECT COUNT(*) as cnt FROM debit_notes WHERE company_id = ?', [companyId]);
      const num = `DN-${new Date().getFullYear()}-${String(count[0].cnt + 1).padStart(3, '0')}`;
      const id = await debitNoteModel.create({ ...req.body, company_id: companyId, debit_note_number: num, created_by: req.user?.id });
      return successResponse(res, 201, 'Debit note created', { id, debit_note_number: num });
    } catch (err) { return errorResponse(res, 500, err.message); }
  },
  async update(req, res) {
    try {
      await debitNoteModel.update(req.params.id, req.body);
      return successResponse(res, 200, 'Debit note updated');
    } catch (err) { return errorResponse(res, 500, err.message); }
  }
};


const invoiceController = {
  async getAll(req, res) {
    try {
      const userRoleId = Number(req.user?.role_id);
      const userRole = String(req.user?.role || req.user?.role_name || '').toLowerCase();
      const isSuperAdmin = userRoleId === 1 || userRole.includes('super');

      let companyId;
      if (isSuperAdmin) {
        companyId = req.headers['x-company-id'] || req.query?.company_id || req.user?.company_id;
      } else {
        companyId = req.user?.company_id;
      }
      if (!companyId) return errorResponse(res, 400, 'Company ID is required');

      const branchId = isSuperAdmin 
        ? (req.headers['x-branch-id'] || req.query.branch_id || req.user?.branch_id)
        : (req.user?.branch_id || req.headers['x-branch-id'] || req.query.branch_id);

      let query = `
        SELECT i.*, c.company_name as client_company_name, c.primary_contact_name as client_contact_name,
               b.name as branch_name
        FROM invoices i
        LEFT JOIN customers c ON i.client_id = c.id
        LEFT JOIN branches b ON i.branch_id = b.id
        WHERE i.company_id = ?
      `;
      const params = [companyId];
      if (branchId && branchId !== 'all') {
        query += ' AND (i.branch_id = ? OR i.branch_id IS NULL)';
        params.push(branchId);
      }
      query += ' ORDER BY i.created_at DESC';
      const [rows] = await require('../config/db').execute(query, params);
      return successResponse(res, 200, 'Invoices fetched', rows);
    } catch (err) {
      return errorResponse(res, 500, err.message);
    }
  },

  async getById(req, res) {
    try {
      const pool = require('../config/db');
      const [rows] = await pool.execute(
        `SELECT i.*, c.company_name as client_company_name, b.name as branch_name
         FROM invoices i
         LEFT JOIN customers c ON i.client_id = c.id
         LEFT JOIN branches b ON i.branch_id = b.id
         WHERE i.id = ?`,
        [req.params.id]
      );
      if (!rows[0]) return errorResponse(res, 404, 'Invoice not found');
      const [items] = await pool.execute(
        'SELECT * FROM invoice_items WHERE invoice_id = ?',
        [req.params.id]
      ).catch(() => [[]]);
      return successResponse(res, 200, 'Invoice fetched', { ...rows[0], items: items || [] });
    } catch (err) {
      return errorResponse(res, 500, err.message);
    }
  },

  async create(req, res) {
    const pool = require('../config/db');
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();

      const userRoleId = Number(req.user?.role_id);
      const userRole = String(req.user?.role || req.user?.role_name || '').toLowerCase().trim();
      const isSuperAdmin = userRoleId === 1 || userRole === 'super admin' || userRole === 'superadmin';

      const companyId = isSuperAdmin
        ? (req.headers['x-company-id'] || req.body.company_id || req.user?.company_id)
        : req.user?.company_id;
      if (!companyId) {
        conn.release();
        return errorResponse(res, 400, 'Company ID is required');
      }

      const branchId = isSuperAdmin
        ? (req.body.branch_id || req.headers['x-branch-id'] || req.user?.branch_id || null)
        : (req.user?.branch_id || req.body.branch_id || null);

      const { client_id, subtotal, total_amount, due_date, notes, status, invoice_number, items } = req.body;

      const now = new Date();
      const d = String(now.getDate()).padStart(2, '0');
      const m = String(now.getMonth() + 1).padStart(2, '0');
      const y = String(now.getFullYear());
      const dateStr = `${d}${m}${y}`;
      const isNonGst = Boolean(req.body.is_nongst || req.body.is_non_gst || req.body.scheme === 'Non-GST' || req.body.type === 'nongst');
      const prefix = isNonGst ? `NG-${dateStr}` : `INV-${dateStr}`;

      let num = invoice_number;
      if (!num) {
        const [count] = await conn.execute('SELECT COUNT(*) as cnt FROM invoices WHERE company_id = ? FOR UPDATE', [companyId]).catch(() => [[{ cnt: 0 }]]);
        const seq = ((count && count[0] ? count[0].cnt : 0) + 1).toString().padStart(3, '0');
        num = `${prefix}${seq}`;
        // Verify uniqueness
        const [existing] = await conn.execute('SELECT id FROM invoices WHERE invoice_number = ?', [num]);
        if (existing.length > 0) {
          num = `${prefix}${seq}-${Date.now().toString().slice(-4)}`;
        }
      }

      const [result] = await conn.execute(
        `INSERT INTO invoices (company_id, branch_id, client_id, invoice_number, subtotal, total_amount, status, due_date, notes, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [companyId, branchId, client_id || null, num, subtotal || total_amount || 0, total_amount || subtotal || 0, status || 'unpaid', due_date || null, notes || null, req.user?.id || null]
      );
      const invoiceId = result.insertId;

      if (Array.isArray(items) && items.length > 0) {
        for (const item of items) {
          await conn.execute(
            `INSERT INTO invoice_items (invoice_id, product_id, description, quantity, unit_price, discount_percent, tax_percent, total)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              invoiceId,
              item.product_id || item.productId || null,
              item.description || item.name || 'Item',
              item.quantity || 1,
              item.unit_price || item.unitPrice || item.rate || 0,
              item.discount_percent || item.discount || 0,
              item.tax_percent || item.taxPercent || item.tax || 0,
              item.total || ((Number(item.quantity) || 1) * (Number(item.unit_price) || 0))
            ]
          );
        }
      }

      await conn.commit();
      return successResponse(res, 201, 'Invoice created successfully', { id: invoiceId, invoice_number: num });
    } catch (err) {
      await conn.rollback();
      return errorResponse(res, 500, err.message);
    } finally {
      conn.release();
    }
  },

  async update(req, res) {
    const pool = require('../config/db');
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();

      const userRoleId = Number(req.user?.role_id);
      const userRole = String(req.user?.role || req.user?.role_name || '').toLowerCase().trim();
      const isSuperAdmin = userRoleId === 1 || userRole === 'super admin' || userRole === 'superadmin';

      // Check ownership
      const [inv] = await conn.execute('SELECT company_id FROM invoices WHERE id = ?', [req.params.id]);
      if (!inv.length) {
        conn.release();
        return errorResponse(res, 404, 'Invoice not found');
      }
      if (!isSuperAdmin && String(inv[0].company_id) !== String(req.user?.company_id)) {
        conn.release();
        return errorResponse(res, 403, 'Access denied: You can only edit invoices for your assigned company');
      }

      const allowedColumns = [
        'branch_id', 'client_id', 'invoice_number', 'subtotal', 'total_amount', 
        'status', 'due_date', 'notes', 'currency', 'tax_amount', 'discount_amount'
      ];
      const fields = [];
      const values = [];
      for (const [key, val] of Object.entries(req.body)) {
        if (allowedColumns.includes(key) && val !== undefined) {
          fields.push(`${key} = ?`);
          values.push(val);
        }
      }

      if (fields.length > 0) {
        values.push(req.params.id);
        await conn.execute(`UPDATE invoices SET ${fields.join(', ')} WHERE id = ?`, values);
      }

      if (Array.isArray(req.body.items)) {
        await conn.execute('DELETE FROM invoice_items WHERE invoice_id = ?', [req.params.id]);
        for (const item of req.body.items) {
          await conn.execute(
            `INSERT INTO invoice_items (invoice_id, product_id, description, quantity, unit_price, discount_percent, tax_percent, total)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              req.params.id,
              item.product_id || item.productId || null,
              item.description || item.name || 'Item',
              item.quantity || 1,
              item.unit_price || item.unitPrice || item.rate || 0,
              item.discount_percent || item.discount || 0,
              item.tax_percent || item.taxPercent || item.tax || 0,
              item.total || ((Number(item.quantity) || 1) * (Number(item.unit_price) || 0))
            ]
          );
        }
      }

      await conn.commit();
      return successResponse(res, 200, 'Invoice updated');
    } catch (err) {
      await conn.rollback();
      return errorResponse(res, 500, err.message);
    } finally {
      conn.release();
    }
  },

  async delete(req, res) {
    const pool = require('../config/db');
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();

      const userRoleId = Number(req.user?.role_id);
      const userRole = String(req.user?.role || req.user?.role_name || '').toLowerCase().trim();
      if (userRole.includes('client')) {
        conn.release();
        return errorResponse(res, 403, 'Clients are not permitted to delete invoices');
      }
      const isSuperAdmin = userRoleId === 1 || userRole === 'super admin' || userRole === 'superadmin';

      const [inv] = await conn.execute('SELECT company_id FROM invoices WHERE id = ?', [req.params.id]);
      if (!inv.length) {
        conn.release();
        return errorResponse(res, 404, 'Invoice not found');
      }
      if (!isSuperAdmin && String(inv[0].company_id) !== String(req.user?.company_id)) {
        conn.release();
        return errorResponse(res, 403, 'Access denied: You can only delete invoices for your assigned company');
      }

      await conn.execute('DELETE FROM invoice_items WHERE invoice_id = ?', [req.params.id]).catch(() => {});
      await conn.execute('DELETE FROM invoices WHERE id = ?', [req.params.id]);

      await conn.commit();
      return successResponse(res, 200, 'Invoice deleted');
    } catch (err) {
      await conn.rollback();
      return errorResponse(res, 500, err.message);
    } finally {
      conn.release();
    }
  }
};

module.exports = {
  invoiceController, quotationController, estimateController, salesOrderController, paymentController, creditNoteController, debitNoteController };
