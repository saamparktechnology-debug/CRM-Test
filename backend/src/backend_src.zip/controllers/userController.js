const pool = require('../config/db');
const { successResponse, errorResponse } = require('../utils/apiResponse');

// Ensure required columns exist in users table (auto-migrate if missing on any domain / environment)
async function ensureUsersColumns() {
  try {
    await pool.execute('ALTER TABLE users ADD COLUMN avatar_url TEXT NULL').catch(() => {});
    await pool.execute('ALTER TABLE users ADD COLUMN sub_branch_id INT NULL').catch(() => {});
    await pool.execute('ALTER TABLE users ADD COLUMN username VARCHAR(100) NULL').catch(() => {});
    await pool.execute('ALTER TABLE users ADD COLUMN company_ids TEXT NULL').catch(() => {});
    await pool.execute('ALTER TABLE users MODIFY COLUMN phone VARCHAR(100) NULL').catch(() => {});
    await pool.execute("ALTER TABLE users ADD COLUMN kyc_status ENUM('Pending', 'Processing', 'Verified', 'Rejected') DEFAULT 'Pending'").catch(() => {});
    await pool.execute('ALTER TABLE users ADD COLUMN kyc_data LONGTEXT NULL').catch(() => {});
  } catch {}
}
ensureUsersColumns();

const COMP_ALIASES = {
  '1': 'tech',
  'tech': '1',
  '2': 'digital',
  'digital': '2',
  '3': 'saampark-ai-solutions',
  'saampark-ai-solutions': '3',
  '4': 'consultancy',
  'consultancy': '4'
};

// Helper: Resolve requesting user info from authenticated JWT token
async function resolveRequester(req) {
  if (req.user && req.user.id) {
    try {
      const [rows] = await pool.execute(
        'SELECT id, email, role_id, company_id, company_ids, branch_id, sub_branch_id FROM users WHERE id = ? AND deleted_at IS NULL',
        [req.user.id]
      );
      if (rows.length > 0) return rows[0];
    } catch {}
    return req.user;
  }
  return { role_id: 3, role_name: 'Teams' }; // default Teams
}

// Helper: Check if target company is in requester's assigned company scope
function isCompanyInScope(creator, targetComp) {
  if (!creator || creator.role_id === 1) return true; // Super Admin can access any company
  if (!targetComp || targetComp === 'all') return true;
  const targetNorm = String(targetComp || '').toLowerCase().trim();
  let allowed = [];
  if (creator.company_ids) {
    try {
      const parsed = typeof creator.company_ids === 'string' ? JSON.parse(creator.company_ids) : creator.company_ids;
      if (Array.isArray(parsed)) allowed = parsed.map(c => String(c).toLowerCase().trim());
    } catch {}
  }
  if (creator.company_id) {
    allowed.push(String(creator.company_id).toLowerCase().trim());
  }
  if (allowed.length === 0) return true;
  return allowed.some(a => a === targetNorm || COMP_ALIASES[a] === targetNorm || COMP_ALIASES[targetNorm] === a);
}

// ─── GET ALL USERS ────────────────────────────────────────────────────────────
const getAllUsers = async (req, res, next) => {
  try {
    ensureUsersColumns().catch(() => {});
    const requester = await resolveRequester(req);
    const companyId = req.query.company_id || req.query.companyId || req.companySlug || req.companyId || req.headers['x-company-id'];
    const branchId = req.query.branch_id || req.query.branchId || req.headers['x-branch-id'];
    const subBranchId = req.query.sub_branch_id || req.query.subBranchId || req.headers['x-sub-branch-id'];

    let query = `
      SELECT u.id, u.full_name, u.email, u.username, u.phone, u.department, u.status, u.permissions, u.last_login, u.created_at,
             u.company_id, u.company_ids, u.branch_id, u.sub_branch_id, u.avatar_url,
             u.kyc_status, u.kyc_data,
             r.name as role_name, r.id as role_id,
             b.name as branch_name, sb.name as sub_branch_name, c.name as company_name
      FROM users u
      LEFT JOIN roles r ON u.role_id = r.id
      LEFT JOIN branches b ON (u.branch_id = b.id OR LOWER(u.branch_id) = LOWER(b.name))
      LEFT JOIN sub_branches sb ON (u.sub_branch_id = sb.id OR LOWER(u.sub_branch_id) = LOWER(sb.name))
      LEFT JOIN companies c ON (u.company_id = c.id OR u.company_id = c.slug)
      WHERE u.deleted_at IS NULL
    `;
    const params = [];

    // Role-based scoping
    if (requester.role_id === 1) {
      // Super Admin:
      // Can switch between companies and branches
      if (companyId && companyId !== 'all') {
        query += ` AND (u.company_id = ? OR u.company_id = ? OR JSON_CONTAINS(COALESCE(u.company_ids, '[]'), JSON_QUOTE(?)) OR JSON_CONTAINS(COALESCE(u.company_ids, '[]'), JSON_QUOTE(?)))`;
        params.push(String(req.companyId || companyId), String(req.companySlug || companyId), String(req.companyId || companyId), String(req.companySlug || companyId));
      }
      if (branchId && branchId !== 'all') {
        query += ` AND (u.branch_id = ? OR b.name = ?)`;
        params.push(branchId, branchId);
      }
      if (subBranchId && subBranchId !== 'all') {
        query += ` AND (u.sub_branch_id = ? OR sb.name = ?)`;
        params.push(subBranchId, subBranchId);
      }
    } else if (requester.role_id === 2 && requester.branch_id) {
      // Branch Admin: locked strictly to their assigned branch!
      query += ` AND u.branch_id = ?`;
      params.push(requester.branch_id);
      if (subBranchId && subBranchId !== 'all') {
        query += ` AND u.sub_branch_id = ?`;
        params.push(subBranchId);
      }
    } else if (requester.role_id === 2) {
      // Company Admin (no specific branch assigned):
      let compList = [];
      if (requester.company_ids) {
        try {
          const parsed = typeof requester.company_ids === 'string' ? JSON.parse(requester.company_ids) : requester.company_ids;
          if (Array.isArray(parsed)) compList = parsed;
        } catch {}
      }
      if (requester.company_id && !compList.includes(requester.company_id)) {
        compList.push(requester.company_id);
      }
      if (compList.length === 0) compList = ['tech'];

      const targetComp = (companyId && companyId !== 'all') ? companyId : null;
      if (targetComp) {
        // Enforce that targetComp belongs to Admin's assigned companies
        const isAllowed = compList.some(c => 
          String(c).toLowerCase().trim() === String(targetComp).toLowerCase().trim() ||
          (req.companyId && String(c).toLowerCase().trim() === String(req.companyId).toLowerCase().trim()) ||
          (req.companySlug && String(c).toLowerCase().trim() === String(req.companySlug).toLowerCase().trim())
        );
        if (!isAllowed) {
          return errorResponse(res, 403, 'Access denied: You can only view users in your assigned company.');
        }
        query += ` AND (u.company_id = ? OR u.company_id = ? OR JSON_CONTAINS(COALESCE(u.company_ids, '[]'), JSON_QUOTE(?)) OR JSON_CONTAINS(COALESCE(u.company_ids, '[]'), JSON_QUOTE(?)))`;
        params.push(String(req.companyId || targetComp), String(req.companySlug || targetComp), String(req.companyId || targetComp), String(req.companySlug || targetComp));
      } else {
        const compPlaceholders = compList.map(() => '?').join(', ');
        query += ` AND (u.company_id IN (${compPlaceholders}))`;
        params.push(...compList.map(String));
      }

      if (branchId && branchId !== 'all') {
        query += ` AND u.branch_id = ?`;
        params.push(branchId);
      }
      if (subBranchId && subBranchId !== 'all') {
        query += ` AND u.sub_branch_id = ?`;
        params.push(subBranchId);
      }
    } else {
      // Teams / Clients: Strictly locked to their assigned company & branch
      const userCompany = requester.company_id || 'tech';
      query += ` AND (u.company_id = ? OR u.company_id = ?)`;
      params.push(String(userCompany), String(req.companySlug || userCompany));

      const effectiveBranch = requester.branch_id;
      if (effectiveBranch) {
        query += ` AND u.branch_id = ?`;
        params.push(effectiveBranch);
      }
    }

    query += ` ORDER BY u.id DESC`;
    let users = [];
    try {
      const [rows] = await pool.execute(query, params);
      users = rows;
    } catch (qErr) {
      if (qErr.code === 'ER_BAD_FIELD_ERROR' && (qErr.message.includes('username') || qErr.sqlMessage?.includes('username'))) {
        const fallbackQuery = query.replace('u.username,', 'NULL as username,');
        const [rows] = await pool.execute(fallbackQuery, params);
        users = rows;
      } else {
        throw qErr;
      }
    }
    const mappedUsers = (users || []).map(u => ({
      ...u,
      name: u.full_name || u.name || u.username || u.email || 'User',
      role: u.role_name || u.role || 'Teams'
    }));
    return successResponse(res, 200, 'Users fetched successfully', mappedUsers);
  } catch (error) {
    next(error);
  }
};

// ─── GET USER BY ID ───────────────────────────────────────────────────────────
const getUserById = async (req, res, next) => {
  try {
    const { id } = req.params;
    let users = [];
    try {
      const [rows] = await pool.execute(
        `SELECT u.id, u.full_name, u.email, u.username, u.phone, u.department, u.status, u.permissions, u.company_id, u.company_ids, u.branch_id, u.sub_branch_id, u.avatar_url,
                u.kyc_status, u.kyc_data,
                r.name as role_name, r.id as role_id,
                b.name as branch_name, sb.name as sub_branch_name, c.name as company_name
         FROM users u
         LEFT JOIN roles r ON u.role_id = r.id
         LEFT JOIN branches b ON (u.branch_id = b.id OR LOWER(u.branch_id) = LOWER(b.name))
         LEFT JOIN sub_branches sb ON (u.sub_branch_id = sb.id OR LOWER(u.sub_branch_id) = LOWER(sb.name))
         LEFT JOIN companies c ON (u.company_id = c.id OR u.company_id = c.slug)
         WHERE (u.id = ? OR u.email = ?) AND u.deleted_at IS NULL`,
        [id, id]
      );
      users = rows;
    } catch (qErr) {
      if (qErr.code === 'ER_BAD_FIELD_ERROR' && (qErr.message.includes('username') || qErr.sqlMessage?.includes('username'))) {
        const [rows] = await pool.execute(
          `SELECT u.id, u.full_name, u.email, NULL as username, u.phone, u.department, u.status, u.permissions, u.company_id, u.company_ids, u.branch_id, u.sub_branch_id, u.avatar_url,
                  u.kyc_status, u.kyc_data,
                  r.name as role_name, r.id as role_id,
                  b.name as branch_name, sb.name as sub_branch_name, c.name as company_name
           FROM users u
           LEFT JOIN roles r ON u.role_id = r.id
           LEFT JOIN branches b ON (u.branch_id = b.id OR LOWER(u.branch_id) = LOWER(b.name))
           LEFT JOIN sub_branches sb ON (u.sub_branch_id = sb.id OR LOWER(u.sub_branch_id) = LOWER(sb.name))
           LEFT JOIN companies c ON (u.company_id = c.id OR u.company_id = c.slug)
           WHERE (u.id = ? OR u.email = ?) AND u.deleted_at IS NULL`,
          [id, id]
        );
        users = rows;
      } else {
        throw qErr;
      }
    }

    if (users.length === 0) {
      return errorResponse(res, 404, 'User not found.');
    }

    return successResponse(res, 200, 'User details fetched', users[0]);
  } catch (error) {
    next(error);
  }
};

// ─── UPDATE USER ──────────────────────────────────────────────────────────────
const updateUser = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { 
      full_name, name, email, username, password, phone, role_id, status, 
      permissions, department, company_id, company_ids, companyIds, 
      branch_id, branchId, sub_branch_id, subBranchId,
      avatar_url, avatar, avatarUrl 
    } = req.body;

    const requester = await resolveRequester(req);

    const displayName = full_name || name || null;
    const phoneVal = phone !== undefined ? (phone || null) : null;
    const statusVal = status || null;
    const avatarVal = avatar_url || avatar || avatarUrl || null;
    const usernameVal = username !== undefined ? (username ? username.toLowerCase().trim() : null) : undefined;
    const branchIdVal = branch_id !== undefined ? (branch_id || null) : (branchId !== undefined ? (branchId || null) : undefined);
    const subBranchIdVal = sub_branch_id !== undefined ? (sub_branch_id || null) : (subBranchId !== undefined ? (subBranchId || null) : undefined);
    
    let roleIdVal = role_id ? parseInt(role_id, 10) : null;
    if (!roleIdVal && req.body.role) {
      const rLower = String(req.body.role).toLowerCase();
      if (rLower.includes('super')) roleIdVal = 1;
      else if (rLower.includes('admin')) roleIdVal = 2;
      else if (rLower.includes('client')) roleIdVal = 4;
      else roleIdVal = 3;
    }

    const newEmailVal = email ? email.toLowerCase().trim() : null;
    const oldEmailVal = (req.body.old_email || req.body.oldEmail || '').toLowerCase().trim();
    const targetEmail = (oldEmailVal || newEmailVal || id || '').toLowerCase().trim();

    // 🛡️ PRIMARY ROOT SUPER ADMIN PROTECTION:
    // saampark.official@gmail.com must ALWAYS remain Super Admin (role_id: 1)
    // No one can demote or change this master account's role.
    const isNumericId = !isNaN(parseInt(id, 10)) && !String(id).startsWith('usr_');
    let isRootSuperAccount = 
      targetEmail === 'saampark.official@gmail.com' || 
      newEmailVal === 'saampark.official@gmail.com' ||
      oldEmailVal === 'saampark.official@gmail.com';

    if (!isRootSuperAccount) {
      try {
        const [existingRows] = await pool.execute(
          'SELECT email FROM users WHERE id = ? OR email = ?',
          [isNumericId ? parseInt(id, 10) : 0, targetEmail]
        );
        if (existingRows.length > 0 && (existingRows[0].email || '').toLowerCase().trim() === 'saampark.official@gmail.com') {
          isRootSuperAccount = true;
        }
      } catch {}
    }

    if (isRootSuperAccount) {
      roleIdVal = 1; // Unconditionally keep as Super Admin
    }

    // RBAC Hierarchy Enforcement:
    // Only a Super Admin can promote/assign Super Admin (1) or Admin (2)
    if (roleIdVal === 1 || roleIdVal === 2) {
      if (requester.role_id !== 1 && !isRootSuperAccount) {
        return errorResponse(res, 403, 'Access denied: Only a Super Admin can create or change a user role to Super Admin or Admin.');
      }
    }

    // Company Scoping for Admin:
    if (requester.role_id === 2 && company_id) {
      if (!isCompanyInScope(requester, company_id)) {
        return errorResponse(res, 403, 'Access denied: Admins cannot assign users outside their assigned company.');
      }
    }

    // Branch Scoping for Branch Admin:
    if (requester.role_id === 2 && requester.branch_id && branchIdVal !== undefined) {
      if (branchIdVal && String(branchIdVal) !== String(requester.branch_id)) {
        return errorResponse(res, 403, 'Access denied: Branch Admins can only assign users to their assigned branch.');
      }
    }

    // Multi-company serialization
    const compList = company_ids || companyIds || (company_id ? [company_id] : null);
    const compIdsStr = Array.isArray(compList) ? JSON.stringify(compList) : (typeof compList === 'string' ? compList : null);

    // Build dynamic SET clause
    const setClauses = [];
    const params = [];

    if (displayName !== null) { setClauses.push('full_name = ?'); params.push(displayName); }
    if (newEmailVal) { setClauses.push('email = ?'); params.push(newEmailVal); }
    if (usernameVal !== undefined) { setClauses.push('username = ?'); params.push(usernameVal); }
    if (phoneVal !== null || phone === '') { setClauses.push('phone = ?'); params.push(phoneVal); }
    if (statusVal) { setClauses.push('status = ?'); params.push(statusVal); }
    if (roleIdVal) { setClauses.push('role_id = ?'); params.push(roleIdVal); }
    if (company_id) { setClauses.push('company_id = ?'); params.push(company_id); }
    if (compIdsStr) { setClauses.push('company_ids = ?'); params.push(compIdsStr); }
    if (branchIdVal !== undefined) { setClauses.push('branch_id = ?'); params.push(branchIdVal); }
    if (subBranchIdVal !== undefined) { setClauses.push('sub_branch_id = ?'); params.push(subBranchIdVal); }
    if (department !== undefined) { setClauses.push('department = ?'); params.push(department || null); }
    if (avatarVal !== null) { setClauses.push('avatar_url = ?'); params.push(avatarVal); }
    
    // KYC Fields
    const kycStatusVal = req.body.kyc_status || req.body.kycStatus;
    if (kycStatusVal !== undefined && kycStatusVal !== null) {
      setClauses.push('kyc_status = ?');
      params.push(kycStatusVal);
    }
    const kycDataVal = req.body.kyc_data || req.body.kycData;
    if (kycDataVal !== undefined && kycDataVal !== null) {
      const kycStr = typeof kycDataVal === 'string' ? kycDataVal : JSON.stringify(kycDataVal);
      setClauses.push('kyc_data = ?');
      params.push(kycStr);
    }

    if (permissions !== undefined && permissions !== null) {
      const permStr = typeof permissions === 'string' ? permissions : JSON.stringify(permissions);
      setClauses.push('permissions = ?');
      params.push(permStr);
    }
    if (password && typeof password === 'string' && password.trim().length >= 6) {
      const { hashPassword } = require('../utils/passwordHash');
      const hashedPassword = await hashPassword(password.trim());
      setClauses.push('password_hash = ?');
      params.push(hashedPassword);
    }

    if (setClauses.length === 0) {
      return successResponse(res, 200, 'No changes to update.');
    }

    setClauses.push('updated_at = NOW()');
    const isNumericTargetId = !isNaN(parseInt(id, 10)) && Number(id) > 0;
    
    try {
      if (isNumericTargetId) {
        params.push(parseInt(id, 10));
        await pool.execute(
          `UPDATE users SET ${setClauses.join(', ')} WHERE id = ?`,
          params
        );
      } else {
        params.push(targetEmail || id);
        await pool.execute(
          `UPDATE users SET ${setClauses.join(', ')} WHERE email = ?`,
          params
        );
      }
    } catch (updErr) {
      if (updErr.code === 'ER_BAD_FIELD_ERROR' && (updErr.message.includes('username') || updErr.sqlMessage?.includes('username'))) {
        const fallbackSetClauses = setClauses.filter(c => !c.startsWith('username ='));
        const usernameIdx = setClauses.findIndex(c => c.startsWith('username ='));
        const fallbackParams = [...params];
        if (usernameIdx >= 0) fallbackParams.splice(usernameIdx, 1);
        if (isNumericTargetId) {
          await pool.execute(
            `UPDATE users SET ${fallbackSetClauses.join(', ')} WHERE id = ? OR email = ? OR email = ?`,
            fallbackParams
          );
        } else {
          await pool.execute(
            `UPDATE users SET ${fallbackSetClauses.join(', ')} WHERE email = ? OR email = ?`,
            fallbackParams
          );
        }
      } else {
        throw updErr;
      }
    }

    // Also sync updated user record & permissions into app_data JSON store
    try {
      const [appDataRows] = await pool.execute('SELECT data_json FROM app_data WHERE module_key = "users"');
      let currentUsers = [];
      if (appDataRows.length > 0) {
        try { currentUsers = JSON.parse(appDataRows[0].data_json) } catch {}
      }
      if (!Array.isArray(currentUsers)) currentUsers = [];

      const lookupEmail = newEmailVal || targetEmail;
      const [updatedUserRows] = await pool.execute(
        'SELECT u.*, r.name as role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ? OR u.email = ? OR u.email = ? OR u.email = ?',
        [id, lookupEmail, targetEmail, oldEmailVal || targetEmail]
      ).catch(() => [[]]);

      let effBranchId = branchIdVal !== undefined ? branchIdVal : (req.body.branch_id || req.body.branchId || undefined);
      let effBranchName = req.body.branch_name || req.body.branchName;
      if (effBranchId && !effBranchName) {
        try {
          const [bRows] = await pool.execute('SELECT name FROM branches WHERE id = ? OR LOWER(name) = LOWER(?)', [effBranchId, effBranchId]);
          if (bRows.length > 0) effBranchName = bRows[0].name;
        } catch {}
      }
      let effSubBranchId = subBranchIdVal !== undefined ? subBranchIdVal : (req.body.sub_branch_id || req.body.subBranchId || undefined);
      let effSubBranchName = req.body.sub_branch_name || req.body.subBranchName;
      if (effSubBranchId && !effSubBranchName) {
        try {
          const [sbRows] = await pool.execute('SELECT name FROM sub_branches WHERE id = ? OR LOWER(name) = LOWER(?)', [effSubBranchId, effSubBranchId]);
          if (sbRows.length > 0) effSubBranchName = sbRows[0].name;
        } catch {}
      }

      let updatedItem = null;

      if (updatedUserRows.length > 0) {
        const u = updatedUserRows[0];
        const emailNorm = (u.email || '').toLowerCase().trim();
        let permObj = null;
        if (typeof u.permissions === 'string') {
          try { permObj = JSON.parse(u.permissions); } catch {}
        } else if (u.permissions && typeof u.permissions === 'object') {
          permObj = u.permissions;
        }

        let parsedCompanyIds = [];
        if (u.company_ids) {
          try { parsedCompanyIds = JSON.parse(u.company_ids); } catch { parsedCompanyIds = [u.company_ids]; }
        }
        if (!Array.isArray(parsedCompanyIds) || parsedCompanyIds.length === 0) {
          parsedCompanyIds = [u.company_id || 'tech'];
        }

        const effectiveAvatar = avatarVal || u.avatar_url || undefined;
        effBranchId = branchIdVal !== undefined ? branchIdVal : (u.branch_id || effBranchId);
        effSubBranchId = subBranchIdVal !== undefined ? subBranchIdVal : (u.sub_branch_id || effSubBranchId);

        updatedItem = {
          id: String(u.id),
          name: u.full_name || u.email,
          email: emailNorm,
          username: u.username || (usernameVal !== undefined ? usernameVal : undefined),
          role: u.role_name || (u.role_id === 1 ? 'Super Admin' : u.role_id === 2 ? 'Admin' : u.role_id === 4 ? 'Clients' : 'Teams'),
          companyId: u.company_id || 'tech',
          companyIds: parsedCompanyIds,
          companyName: u.company_name || 'SAAMPARK Technology',
          branchId: effBranchId || undefined,
          branchName: effBranchName || undefined,
          subBranchId: effSubBranchId || undefined,
          subBranchName: effSubBranchName || undefined,
          avatarUrl: effectiveAvatar,
          avatar: effectiveAvatar,
          status: u.status === 'inactive' ? 'Inactive' : 'Active',
          department: u.department || 'General',
          phone: u.phone || '',
          permissions: permObj,
          allowedModules: permObj?.allowedModules,
          kycStatus: u.kyc_status || (kycStatusVal !== undefined ? kycStatusVal : undefined),
          kycData: (() => {
            try {
              if (u.kyc_data) return typeof u.kyc_data === 'string' ? JSON.parse(u.kyc_data) : u.kyc_data;
              if (kycDataVal) return typeof kycDataVal === 'string' ? JSON.parse(kycDataVal) : kycDataVal;
            } catch {}
            return undefined;
          })(),
        };
      } else {
        // Fallback for accounts tracked directly via app_data (e.g. system accounts with string IDs)
        const targetIdStr = String(id).toLowerCase().trim();
        const existingIdx = currentUsers.findIndex(cu => 
          String(cu.id || '').toLowerCase().trim() === targetIdStr ||
          (cu.email && cu.email.toLowerCase().trim() === targetEmail) ||
          (oldEmailVal && cu.email && cu.email.toLowerCase().trim() === oldEmailVal)
        );
        const existingCu = existingIdx >= 0 ? currentUsers[existingIdx] : {};
        updatedItem = {
          ...existingCu,
          id: id,
          name: displayName || existingCu.name || targetEmail,
          email: newEmailVal || targetEmail,
          phone: phoneVal !== null ? phoneVal : (existingCu.phone || ''),
          department: department !== undefined ? department : (existingCu.department || 'General'),
          status: statusVal ? (statusVal === 'inactive' ? 'Inactive' : 'Active') : (existingCu.status || 'Active'),
          role: req.body.role || existingCu.role || (roleIdVal === 1 ? 'Super Admin' : roleIdVal === 2 ? 'Admin' : 'Teams'),
          companyId: company_id || existingCu.companyId || 'tech',
          companyIds: compList || existingCu.companyIds || ['tech'],
          branchId: effBranchId || existingCu.branchId,
          branchName: effBranchName || existingCu.branchName,
          subBranchId: effSubBranchId || existingCu.subBranchId,
          subBranchName: effSubBranchName || existingCu.subBranchName,
          avatarUrl: avatarVal || existingCu.avatarUrl,
          avatar: avatarVal || existingCu.avatar,
          kycStatus: kycStatusVal !== undefined ? kycStatusVal : existingCu.kycStatus,
          kycData: kycDataVal !== undefined ? (typeof kycDataVal === 'string' ? JSON.parse(kycDataVal) : kycDataVal) : existingCu.kycData,
        };
      }

      if (updatedItem) {
        const emailNorm = (updatedItem.email || '').toLowerCase().trim();
        const filteredUsers = currentUsers.filter((cu) => {
          const cuEmail = (cu.email || '').toLowerCase().trim();
          const cuId = String(cu.id || '').toLowerCase().trim();
          if (cuId && cuId === String(id).toLowerCase().trim()) return false;
          if (cuEmail === emailNorm) return false;
          if (oldEmailVal && cuEmail === oldEmailVal) return false;
          return true;
        });

        const newUsersList = [updatedItem, ...filteredUsers];

        await pool.execute(
          `INSERT INTO app_data (module_key, data_json) VALUES ('users', ?)
           ON DUPLICATE KEY UPDATE data_json = VALUES(data_json), updated_at = NOW()`,
          [JSON.stringify(newUsersList)]
        );
      }
    } catch (appErr) {
      console.warn('App data sync on updateUser warning:', appErr.message);
    }

    return successResponse(res, 200, 'User updated successfully');
  } catch (error) {
    next(error);
  }
};

// ─── TOGGLE USER STATUS ────────────────────────────────────────────────────────
const toggleUserStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const isNum = !isNaN(Number(id)) && Number(id) > 0;
    let users = [];

    if (isNum) {
      [users] = await pool.execute('SELECT id, email, role_id, status FROM users WHERE id = ? AND deleted_at IS NULL', [Number(id)]);
    }
    if (!users.length) {
      [users] = await pool.execute(
        'SELECT id, email, role_id, status FROM users WHERE (email = ? OR (id = 4 AND ? = "usr_root_super_admin")) AND deleted_at IS NULL',
        [id, id]
      );
    }
    if (!users.length) return errorResponse(res, 404, 'User not found.');

    const targetUser = users[0];
    const isSuper = targetUser.role_id === 1 || (targetUser.email && targetUser.email.toLowerCase().trim() === 'saampark.official@gmail.com');
    
    // Super Admin accounts are permanently Active and cannot be deactivated
    if (isSuper) {
      return errorResponse(res, 400, 'Super Admin accounts are permanently active and cannot be deactivated.');
    }

    let newStatus = targetUser.status === 'active' ? 'inactive' : 'active';
    await pool.execute('UPDATE users SET status = ?, updated_at = NOW() WHERE id = ?', [newStatus, targetUser.id]);

    // Synchronize to app_data JSON users store
    try {
      const [appRows] = await pool.execute('SELECT data_json FROM app_data WHERE module_key = "users"');
      if (appRows.length > 0 && appRows[0].data_json) {
        let appUsers = JSON.parse(appRows[0].data_json);
        if (Array.isArray(appUsers)) {
          let appChanged = false;
          appUsers.forEach(u => {
            const uId = String(u.id || '').toLowerCase().trim();
            const uEmail = (u.email || '').toLowerCase().trim();
            const tEmail = (targetUser.email || '').toLowerCase().trim();
            if (uId === String(targetUser.id) || uEmail === tEmail || (isSuper && uId === 'usr_root_super_admin')) {
              u.status = newStatus === 'active' ? 'Active' : 'Inactive';
              appChanged = true;
            }
          });
          if (appChanged) {
            await pool.execute('UPDATE app_data SET data_json = ?, updated_at = NOW() WHERE module_key = "users"', [JSON.stringify(appUsers)]);
          }
        }
      }
    } catch (e) {}

    return successResponse(res, 200, `User ${newStatus === 'active' ? 'activated' : 'deactivated'} successfully`, { status: newStatus });
  } catch (error) {
    next(error);
  }
};

// ─── DELETE USER (SOFT DELETE) ─────────────────────────────────────────────────
const deleteUser = async (req, res, next) => {
  try {
    const { id } = req.params;
    const targetEmail = (req.query?.email || req.body?.email || (String(id).includes('@') ? id : '')).toLowerCase().trim();
    const idLower = String(id).toLowerCase().trim();
    let emailNorm = targetEmail;
    let dbId = isNaN(Number(id)) ? null : parseInt(id, 10);

    // Look up user by ID or email
    const [targetUsers] = await pool.execute(
      'SELECT id, role_id, email FROM users WHERE id = ? OR LOWER(email) = ? OR LOWER(email) = ?',
      [dbId || 0, idLower, emailNorm || idLower]
    );

    if (targetUsers.length > 0) {
      emailNorm = targetUsers[0].email.toLowerCase().trim();
      dbId = targetUsers[0].id;
      if (emailNorm === 'saampark.official@gmail.com') {
        return errorResponse(res, 403, 'Primary Root Super Admin account cannot be deleted.');
      }
      if (targetUsers[0].role_id === 1) {
        return errorResponse(res, 403, 'Super Admin accounts cannot be deleted.');
      }
    }

    // Insert into deleted_items
    if (idLower) await pool.execute('INSERT IGNORE INTO deleted_items (item_id, module_name) VALUES (?, "users")', [idLower]);
    if (emailNorm) await pool.execute('INSERT IGNORE INTO deleted_items (item_id, module_name) VALUES (?, "users")', [emailNorm]);
    if (dbId) await pool.execute('INSERT IGNORE INTO deleted_items (item_id, module_name) VALUES (?, "users")', [String(dbId)]);

    // Soft delete: set deleted_at and deactivate
    await pool.execute(
      'UPDATE users SET deleted_at = NOW(), status = "inactive" WHERE id = ? OR LOWER(email) = ? OR LOWER(email) = ?',
      [dbId || 0, idLower, emailNorm || idLower]
    );

    // Actively purge user from all app_data storage keys
    try {
      const [appRows] = await pool.execute(
        'SELECT id, module_key, data_json FROM app_data WHERE module_key = "users" OR module_key LIKE "users_%"'
      );
      for (const row of appRows) {
        try {
          const parsed = JSON.parse(row.data_json);
          if (Array.isArray(parsed)) {
            const cleaned = parsed.filter(u => {
              if (!u) return false;
              const uId = u.id !== undefined && u.id !== null ? String(u.id).toLowerCase().trim() : '';
              const uEmail = u.email ? String(u.email).toLowerCase().trim() : '';
              if (uId === idLower || (dbIdStr && uId === dbIdStr)) return false;
              if (emailNorm && uEmail === emailNorm) return false;
              if (idLower && (uId === idLower || uEmail === idLower)) return false;
              return true;
            });
            if (cleaned.length !== parsed.length) {
              await pool.execute('UPDATE app_data SET data_json = ?, updated_at = NOW() WHERE id = ?', [JSON.stringify(cleaned), row.id]);
            }
          }
        } catch {}
      }
    } catch (purgeErr) {
      console.warn('app_data user purge warning:', purgeErr);
    }

    return successResponse(res, 200, 'User removed successfully');
  } catch (error) {
    next(error);
  }
};

// ─── CREATE USER (ADMIN / SUPER ADMIN CREATED) ─────────────────────────────────
const createUser = async (req, res, next) => {
  try {
    const { 
      full_name, name, email, username, password, phone, 
      role_id, role, company_id, company_ids, companyIds, companyName, 
      branch_id, branchId, sub_branch_id, subBranchId,
      department, permissions 
    } = req.body;
    const displayName = full_name || name;

    if (!displayName || !email || !password) {
      return errorResponse(res, 400, 'Name, email and password are required.');
    }

    const normEmail = email.toLowerCase().trim();
    const normUsername = username ? username.toLowerCase().trim() : null;

    // Check existing users (including soft-deleted)
    const [existing] = await pool.execute('SELECT id, deleted_at FROM users WHERE email = ?', [normEmail]);

    // Map role string to ID if needed
    let targetRoleId = 3;
    if (role_id) {
      targetRoleId = parseInt(role_id, 10);
    } else if (role) {
      const rLower = role.toLowerCase();
      if (rLower.includes('super')) targetRoleId = 1;
      else if (rLower.includes('admin')) targetRoleId = 2;
      else if (rLower.includes('client')) targetRoleId = 4;
      else targetRoleId = 3;
    }

    const requester = await resolveRequester(req);

    // RBAC Hierarchy Enforcement:
    // Only Super Admin (1) can create or assign Super Admin accounts (1).
    // Admin (2) can create Admins (for their branch/company), Teams (3), and Clients (4).
    if (targetRoleId === 1) {
      if (requester.role_id !== 1) {
        return errorResponse(res, 403, 'Access denied: Only a Super Admin can create or assign Super Admin accounts.');
      }
    }

    // Company Scoping for Admin:
    // Admin can ONLY create users in their assigned company scope
    let targetComp = company_id || (company_ids && company_ids[0]) || (companyIds && companyIds[0]) || null;
    if (requester.role_id === 2) {
      if (!targetComp || targetComp === 'all') {
        targetComp = requester.company_id || 'tech';
      }
      if (!isCompanyInScope(requester, targetComp)) {
        return errorResponse(res, 403, 'Access denied: Admins can only add users to their assigned company.');
      }
    } else if (!targetComp) {
      targetComp = 'tech';
    }

    // Branch Scoping for Branch Admin:
    // If Admin is a Branch Admin, user must be assigned to that branch
    let effectiveBranchId = branch_id || branchId || null;
    let effectiveSubBranchId = sub_branch_id || subBranchId || null;
    if (requester.role_id === 2 && requester.branch_id) {
      if (effectiveBranchId && String(effectiveBranchId) !== String(requester.branch_id)) {
        return errorResponse(res, 403, 'Access denied: Branch Admins can only assign users to their assigned branch.');
      }
      effectiveBranchId = requester.branch_id;
    }

    const { hashPassword } = require('../utils/passwordHash');
    const hashedPassword = await hashPassword(password);
    const safePhone = phone ? String(phone).slice(0, 50) : null;

    const roleName = targetRoleId === 1 ? 'Super Admin' : targetRoleId === 2 ? 'Admin' : targetRoleId === 4 ? 'Clients' : 'Teams';
    const permStr = permissions ? (typeof permissions === 'string' ? permissions : JSON.stringify(permissions)) : null;

    // Multi-company handling
    const compList = company_ids || companyIds || [targetComp];
    const parsedCompList = Array.isArray(compList) ? compList : [compList];
    const compVal = parsedCompList[0] || targetComp || 'tech';
    const compIdsStr = JSON.stringify(parsedCompList);

    let userId = null;
    const isExisting = Array.isArray(existing) && existing.length > 0;

    if (isExisting) {
      // Update existing or reactivate soft deleted account
      userId = existing[0].id;
      try {
        await pool.execute(
          `UPDATE users 
           SET full_name = ?, username = COALESCE(?, username), password_hash = ?, phone = ?, department = ?, 
               company_id = ?, company_ids = ?, branch_id = ?, sub_branch_id = ?, role_id = ?, permissions = ?, 
               is_verified = 1, status = 'active', deleted_at = NULL, updated_at = NOW() 
           WHERE id = ?`,
          [displayName, normUsername, hashedPassword, safePhone, department || null, 
           compVal, compIdsStr, effectiveBranchId || null, effectiveSubBranchId || null, targetRoleId, permStr, userId]
        );
      } catch (updErr) {
        if (updErr.code === 'ER_BAD_FIELD_ERROR' && (updErr.message.includes('username') || updErr.sqlMessage?.includes('username'))) {
          await pool.execute(
            `UPDATE users 
             SET full_name = ?, password_hash = ?, phone = ?, department = ?, 
                 company_id = ?, company_ids = ?, branch_id = ?, sub_branch_id = ?, role_id = ?, permissions = ?, 
                 is_verified = 1, status = 'active', deleted_at = NULL, updated_at = NOW() 
             WHERE id = ?`,
            [displayName, hashedPassword, safePhone, department || null, 
             compVal, compIdsStr, effectiveBranchId || null, effectiveSubBranchId || null, targetRoleId, permStr, userId]
          );
        } else {
          throw updErr;
        }
      }
      // Remove from deleted_items tracking
      await pool.execute('DELETE FROM deleted_items WHERE (item_id = ? OR item_id = ?) AND module_name = "users"', [normEmail, String(userId)]).catch(() => {});
    } else {
      try {
        const [result] = await pool.execute(
          `INSERT INTO users 
           (role_id, full_name, email, username, password_hash, phone, department, company_id, company_ids, branch_id, sub_branch_id, permissions, is_verified, status) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
          [targetRoleId, displayName, normEmail, normUsername, hashedPassword, safePhone, department || null, 
           compVal, compIdsStr, effectiveBranchId || null, effectiveSubBranchId || null, permStr, 'active']
        );
        userId = result.insertId;
      } catch (insErr) {
        if (insErr.code === 'ER_BAD_FIELD_ERROR' && (insErr.message.includes('username') || insErr.sqlMessage?.includes('username'))) {
          const [result] = await pool.execute(
            `INSERT INTO users 
             (role_id, full_name, email, password_hash, phone, department, company_id, company_ids, branch_id, sub_branch_id, permissions, is_verified, status) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
            [targetRoleId, displayName, normEmail, hashedPassword, safePhone, department || null, 
             compVal, compIdsStr, effectiveBranchId || null, effectiveSubBranchId || null, permStr, 'active']
          );
          userId = result.insertId;
        } else {
          throw insErr;
        }
      }
    }

    // Resolve branch and sub-branch names
    let branchName = req.body.branch_name || req.body.branchName || undefined;
    let subBranchName = req.body.sub_branch_name || req.body.subBranchName || undefined;
    if (effectiveBranchId && !branchName) {
      try {
        const [bRows] = await pool.execute('SELECT name FROM branches WHERE id = ? OR LOWER(name) = LOWER(?)', [effectiveBranchId, effectiveBranchId]);
        if (bRows.length > 0) branchName = bRows[0].name;
      } catch {}
    }
    if (effectiveSubBranchId && !subBranchName) {
      try {
        const [sbRows] = await pool.execute('SELECT name FROM sub_branches WHERE id = ? OR LOWER(name) = LOWER(?)', [effectiveSubBranchId, effectiveSubBranchId]);
        if (sbRows.length > 0) subBranchName = sbRows[0].name;
      } catch {}
    }

    // Outer-scoped newUserItem so it is ALWAYS available in response
    const newUserItem = {
      id: String(userId),
      name: displayName,
      email: normEmail,
      username: normUsername || undefined,
      role: roleName,
      companyId: compVal,
      companyIds: parsedCompList,
      companyName: companyName || (compVal === 'digital' ? 'SAAMPARK Digital Marketing' : 'SAAMPARK Technology'),
      branchId: effectiveBranchId || undefined,
      branchName: branchName || undefined,
      subBranchId: effectiveSubBranchId || undefined,
      subBranchName: subBranchName || undefined,
      status: 'Active',
      department: department || 'General',
      phone: phone || '',
      lastLogin: 'Just created',
      joinedDate: new Date().toISOString().split('T')[0],
      permissions: permissions || null,
      allowedModules: permissions?.allowedModules,
    };

    // Sync newly created user to app_data JSON store for real-time cross-browser hydration
    try {
      const [appDataRows] = await pool.execute('SELECT data_json FROM app_data WHERE module_key = "users"');
      let currentUsers = [];
      if (appDataRows.length > 0) {
        try { currentUsers = JSON.parse(appDataRows[0].data_json) } catch {}
      }
      if (!Array.isArray(currentUsers)) currentUsers = [];

      const existingIdx = currentUsers.findIndex((u) => (u.email || '').toLowerCase().trim() === normEmail);
      if (existingIdx >= 0) {
        currentUsers[existingIdx] = { ...currentUsers[existingIdx], ...newUserItem };
      } else {
        currentUsers.unshift(newUserItem);
      }

      await pool.execute(
        `INSERT INTO app_data (module_key, data_json) VALUES ('users', ?)
         ON DUPLICATE KEY UPDATE data_json = VALUES(data_json), updated_at = NOW()`,
        [JSON.stringify(currentUsers)]
      );
    } catch (appDataErr) {
      console.warn('App data sync warning:', appDataErr.message);
    }

    // Send Welcome Email with credentials ONLY for newly registered accounts (never for existing users)
    const compName = companyName || (compVal === 'digital' ? 'SAAMPARK Digital Marketing' : 'SAAMPARK Technology');
    let emailSent = false;
    if (!isExisting) {
      try {
        const { sendAdminCreatedAccountEmail } = require('../utils/emailService');
        await sendAdminCreatedAccountEmail(normEmail, displayName, roleName, compName, password, compVal);
        emailSent = true;
        console.log(`Welcome credentials email sent successfully to new user ${normEmail}`);
      } catch (emailErr) {
        console.warn('Welcome email warning:', emailErr.message);
      }
    } else {
      console.log(`User ${normEmail} already exists. Skipping credentials email dispatch.`);
    }

    return successResponse(res, 201, `User account saved successfully${emailSent ? ' and welcome credentials email sent!' : ' (email sending queued).'}`, { id: userId, user: newUserItem });
  } catch (error) {
    next(error);
  }
};

module.exports = { getAllUsers, getUserById, updateUser, toggleUserStatus, deleteUser, createUser };
