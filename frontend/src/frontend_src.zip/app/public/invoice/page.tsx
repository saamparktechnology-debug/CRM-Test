"use client"

import * as React from "react"
import { useSearchParams } from "next/navigation"
import { 
  Building2, ShieldCheck, 
  Printer, AlertCircle, Share2,
  CheckCircle2, Check
} from "lucide-react"
import { getInvoices, InvoiceItem, clientAcceptInvoice } from "@/features/invoice/services/invoiceService"
import { getCompanyPaymentSettings, CompanyPaymentSettings, DEFAULT_COMPANY_PAYMENT_SETTINGS } from "@/features/settings/services/companyPaymentService"
import { getClients } from "@/features/clients/services/clientService"
import { ClientItem } from "@/features/clients/types"
import { OfficialInvoiceDocument } from "@/features/invoice/components/OfficialInvoiceDocument"
import { fetchModuleDataFromDB } from "@/lib/storageSync"
import { Company, DEFAULT_COMPANIES } from "@/store/useAuthStore"

function PublicInvoiceContent() {
  const searchParams = useSearchParams()
  const rawParam = searchParams.get("id") || searchParams.get("num") || searchParams.get("number") || searchParams.get("invoiceNumber") || searchParams.get("view") || ""
  const invoiceQuery = rawParam.replace(/^#/, "").trim()

  const [invoice, setInvoice] = React.useState<InvoiceItem | null>(null)
  const [paySettings, setPaySettings] = React.useState<CompanyPaymentSettings>(DEFAULT_COMPANY_PAYMENT_SETTINGS)
  const [clientDetails, setClientDetails] = React.useState<ClientItem | null>(null)
  const [resolvedCompany, setResolvedCompany] = React.useState<Company | null>(null)
  const [isLoading, setIsLoading] = React.useState(true)
  const [isCopied, setIsCopied] = React.useState(false)
  const [isAccepting, setIsAccepting] = React.useState(false)
  const [acceptSuccess, setAcceptSuccess] = React.useState(false)

  const handleAcceptInvoice = async () => {
    if (!invoice || isAccepting) return
    setIsAccepting(true)
    try {
      const updated = await clientAcceptInvoice(invoice.id, invoice.client, "Accepted via digital portal", invoice.companyId)
      setInvoice(updated)
      setAcceptSuccess(true)
      setTimeout(() => setAcceptSuccess(false), 5000)
    } catch (err) {
      console.error("Accept invoice failed:", err)
    } finally {
      setIsAccepting(false)
    }
  }

  React.useEffect(() => {
    const loadData = async () => {
      setIsLoading(true)
      try {
        const [allInvoices, settings, allClients, allCompanies] = await Promise.all([
          getInvoices("all").catch(() => []),
          getCompanyPaymentSettings("all").catch(() => DEFAULT_COMPANY_PAYMENT_SETTINGS),
          getClients("all").catch(() => []),
          fetchModuleDataFromDB<Company[]>("companies", DEFAULT_COMPANIES, "all").catch(() => DEFAULT_COMPANIES),
        ])

        setPaySettings(settings)

        if (invoiceQuery) {
          const queryNorm = invoiceQuery.toLowerCase()
          const target = allInvoices.find((i) => {
            const idNorm = (i.id || "").toLowerCase()
            const numNorm = ((i as any).invoiceNumber || (i as any).invoice_number || "").toLowerCase()
            return idNorm === queryNorm || numNorm === queryNorm || idNorm.endsWith(queryNorm) || numNorm.endsWith(queryNorm)
          })

          if (target) {
            setInvoice(target)
            const clientTarget = String(target.client || "").toLowerCase().trim()
            const matchedCli = allClients.find(
              (c) => String(c.name || "").toLowerCase().trim() === clientTarget
            )
            if (matchedCli) setClientDetails(matchedCli)

            const targetCompId = String(target.companyId || (target as any).company || "tech").toLowerCase().trim()
            const targetCompName = String((target as any).companyName || "").toLowerCase().trim()
            const compList = Array.isArray(allCompanies) && allCompanies.length > 0 ? allCompanies : DEFAULT_COMPANIES
            const matchedComp = compList.find(c => {
              const cId = String(c.id || "").toLowerCase().trim()
              const cSlug = String(c.slug || "").toLowerCase().trim()
              const cName = String(c.name || "").toLowerCase().trim()
              const cBrand = String(c.brand_name || "").toLowerCase().trim()
              const cDivision = String(c.division_name || "").toLowerCase().trim()
              return (
                cId === targetCompId || 
                cSlug === targetCompId || 
                cName === targetCompId ||
                (targetCompName && (cName === targetCompName || cBrand === targetCompName || `${cBrand} ${cDivision}`.trim() === targetCompName))
              )
            }) || compList[0] || DEFAULT_COMPANIES[0]
            setResolvedCompany(matchedComp)
          }
        }
      } catch (err) {
        console.error("Failed to load invoice:", err)
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [invoiceQuery])

  const handlePrint = () => {
    window.print()
  }

  const handleShare = () => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href)
      setIsCopied(true)
      setTimeout(() => setIsCopied(false), 2500)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-zinc-50 dark:bg-zinc-950 flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 border-4 border-[#005f69] border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-sm font-semibold text-zinc-600 dark:text-zinc-400">Verifying and loading invoice...</p>
      </div>
    )
  }

  if (!invoice) {
    return (
      <div className="min-h-screen bg-zinc-50 dark:bg-zinc-950 flex flex-col items-center justify-center p-4 text-center">
        <div className="w-16 h-16 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center mb-4 shadow-md">
          <AlertCircle size={32} />
        </div>
        <h2 className="text-lg font-black text-zinc-900 dark:text-zinc-100">Invoice Not Found</h2>
        <p className="text-xs text-zinc-500 max-w-sm mt-1">
          The requested invoice identifier <code className="font-mono bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded font-bold">{invoiceQuery || "EMPTY"}</code> could not be found or has expired.
        </p>
      </div>
    )
  }

  const isGstInvoice = Boolean(
    (Array.isArray(invoice.items) && invoice.items.some(it => (Number(it.gstRate) || 0) > 0 || (Number(it.gstAmount) || 0) > 0)) ||
    (typeof invoice.gstRate === "number" && invoice.gstRate > 0) ||
    (typeof invoice.gstAmount === "number" && invoice.gstAmount > 0)
  )

  const theme = isGstInvoice
    ? {
        primaryBg: "bg-[#005f69]",
        primaryText: "text-[#005f69]",
        headerGradient: "bg-gradient-to-r from-[#005f69] via-[#007380] to-[#008a99]",
      }
    : {
        primaryBg: "bg-[#0284c7]",
        primaryText: "text-[#0284c7]",
        headerGradient: "bg-gradient-to-r from-[#0284c7] via-[#0ea5e9] to-[#38bdf8]",
      }

  return (
    <div className="min-h-screen bg-zinc-100 dark:bg-zinc-950 py-6 px-3 sm:px-6 flex flex-col items-center print:p-0 print:bg-white">
      {/* Top Action Toolbar */}
      <div className="w-full max-w-[840px] flex items-center justify-between gap-3 mb-4 print:hidden">
        <div className="flex items-center gap-2">
          <div className={`w-9 h-9 rounded-xl ${theme.primaryBg} text-white flex items-center justify-center shadow-sm text-lg overflow-hidden`}>
            {resolvedCompany?.logo_url ? (
              <img src={resolvedCompany.logo_url} alt={resolvedCompany.name} className="w-7 h-7 object-contain" />
            ) : (
              resolvedCompany?.logo || <Building2 size={18} />
            )}
          </div>
          <div>
            <span className="text-xs font-black tracking-wide text-zinc-900 dark:text-zinc-100 uppercase block">
              {resolvedCompany?.name || "SAAMPARK GROUP"}
            </span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
              <ShieldCheck size={12} />
              <span>{isGstInvoice ? "Digital Tax Invoice Verified" : "Digital Invoice Verified"}</span>
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {invoice.clientAccepted ? (
            <div className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 font-bold text-xs flex items-center gap-1.5 shadow-2xs">
              <CheckCircle2 size={14} className="text-emerald-600 dark:text-emerald-400" />
              <span>Accepted</span>
            </div>
          ) : (
            <button
              type="button"
              onClick={handleAcceptInvoice}
              disabled={isAccepting}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all cursor-pointer disabled:opacity-50"
              title="Formally accept and confirm this invoice"
            >
              <CheckCircle2 size={14} />
              <span>{isAccepting ? "Accepting..." : acceptSuccess ? "Accepted ✓" : "Accept Invoice"}</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleShare}
            className="px-3 py-1.5 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-xs font-bold text-zinc-700 dark:text-zinc-300 hover:bg-zinc-50 dark:hover:bg-zinc-800 flex items-center gap-1.5 shadow-2xs cursor-pointer"
          >
            <Share2 size={14} />
            <span>{isCopied ? "Link Copied!" : "Share"}</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className={`px-3.5 py-1.5 rounded-xl ${theme.primaryBg} hover:opacity-90 text-white text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer`}
          >
            <Printer size={14} />
            <span>Print / Save PDF</span>
          </button>
        </div>
      </div>

      {/* Acceptance Status Banner */}
      {invoice.clientAccepted ? (
        <div className="w-full max-w-[840px] mb-4 p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 flex items-center justify-between gap-3 text-emerald-900 dark:text-emerald-200 print:hidden shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <CheckCircle2 size={18} />
            </div>
            <div>
              <p className="text-xs font-bold leading-tight">
                Digital Invoice Formally Accepted by Client
              </p>
              <p className="text-[11px] text-emerald-700 dark:text-emerald-400 font-mono mt-0.5">
                Confirmed by {invoice.acceptedBy || invoice.client || "Client"}
                {invoice.acceptedAt ? ` on ${new Date(Number(invoice.acceptedAt) || invoice.acceptedAt).toLocaleDateString("en-IN", { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}` : ""}
              </p>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-[10px] font-black uppercase tracking-wider shrink-0 shadow-2xs">
            ✓ Verified
          </span>
        </div>
      ) : (
        <div className="w-full max-w-[840px] mb-4 p-3 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 flex items-center justify-between gap-3 text-blue-900 dark:text-blue-200 print:hidden shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
              <ShieldCheck size={18} />
            </div>
            <div>
              <p className="text-xs font-bold leading-tight">
                Please review this official invoice and click &ldquo;Accept Invoice&rdquo;
              </p>
              <p className="text-[11px] text-blue-700 dark:text-blue-400 mt-0.5">
                Confirming registers your formal acceptance directly with the administration team.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleAcceptInvoice}
            disabled={isAccepting}
            className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shrink-0 shadow-sm transition-all cursor-pointer disabled:opacity-50"
          >
            {isAccepting ? "Accepting..." : "Accept Now"}
          </button>
        </div>
      )}

      {/* Verified Official Document */}
      <OfficialInvoiceDocument 
        invoice={invoice}
        clientDetails={clientDetails}
        companyDetails={resolvedCompany}
        paySettings={paySettings}
      />
    </div>
  )
}

export default function PublicInvoicePage() {
  return (
    <React.Suspense fallback={
      <div className="min-h-screen bg-zinc-50 dark:bg-zinc-950 flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 border-4 border-[#005f69] border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-sm font-semibold text-zinc-600 dark:text-zinc-400">Verifying security certificate...</p>
      </div>
    }>
      <PublicInvoiceContent />
    </React.Suspense>
  )
}
