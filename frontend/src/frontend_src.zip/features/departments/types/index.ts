export * from "./departments.types"
